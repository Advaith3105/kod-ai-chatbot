import { GoogleGenAI, Part, GenerateContentResponse } from "@google/genai";

const fileToGenerativePart = async (file: File): Promise<Part> => {
  const base64EncodedData = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result.split(',')[1]);
      } else {
        reject(new Error("Failed to read file as a Base64 string."));
      }
    };
    reader.onerror = (error) => reject(error);
    reader.readAsDataURL(file);
  });

  return {
    inlineData: {
      data: base64EncodedData,
      mimeType: file.type,
    },
  };
};

export const runChat = async (prompt: string, file: File | null): Promise<string> => {
  // As per guidelines, API key must come from process.env.API_KEY and is assumed to be set.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
  
  const modelName = 'gemini-2.5-flash';

  const requestParts: Part[] = [];

  if (file) {
    const imagePart = await fileToGenerativePart(file);
    requestParts.push(imagePart);
  }
  if (prompt) {
    requestParts.push({ text: prompt });
  }

  if (requestParts.length === 0) {
    throw new Error("Cannot send an empty message.");
  }

  const response: GenerateContentResponse = await ai.models.generateContent({
    model: modelName,
    contents: { parts: requestParts },
  });

  const text = response.text;
  if (typeof text !== 'string') {
    throw new Error("Received an empty or invalid response from the API.");
  }
  
  return text;
};
