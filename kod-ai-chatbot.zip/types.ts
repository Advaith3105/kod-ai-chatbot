export interface ChatMessagePart {
  text?: string;
  imageData?: {
    url: string;
    mimeType: string;
  };
}

export interface ChatMessage {
  role: 'user' | 'model';
  parts: ChatMessagePart[];
}
