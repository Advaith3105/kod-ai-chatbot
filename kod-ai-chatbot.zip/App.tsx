import React, { useState } from 'react';
import { ChatMessage } from './types';
import ChatHistory from './components/ChatHistory';
import ChatInput from './components/ChatInput';
import ErrorDisplay from './components/ErrorDisplay';
import { runChat } from './services/geminiService';
import Sidebar from './components/Sidebar';

const App: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'model',
      parts: [{ text: 'Hello! How can I help you today?' }],
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSendMessage = async (input: string, file: File | null) => {
    if (!input.trim() && !file) return;

    setError(null);

    const userMessage: ChatMessage = {
      role: 'user',
      parts: [],
    };
    if (file) {
      userMessage.parts.push({
        imageData: {
          url: URL.createObjectURL(file),
          mimeType: file.type
        }
      });
    }
    if (input.trim()) {
      userMessage.parts.push({ text: input.trim() });
    }

    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    try {
      const responseText = await runChat(input, file);
      const botMessage: ChatMessage = {
        role: 'model',
        parts: [{ text: responseText }],
      };
      setMessages(prev => [...prev, botMessage]);
    } catch (e: any) {
      setError(e.message || 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex h-screen bg-gray-50 font-sans">
      <Sidebar />
      <div className="flex flex-col flex-1">
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-4xl mx-auto">
            <ChatHistory messages={messages} isLoading={isLoading} />
          </div>
        </main>
        <footer className="p-6 bg-white border-t border-gray-200">
          <div className="max-w-4xl mx-auto">
            {error && <ErrorDisplay error={error} />}
            <ChatInput onSendMessage={handleSendMessage} isLoading={isLoading} />
          </div>
        </footer>
      </div>
    </div>
  );
};

export default App;
