import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="flex-shrink-0 bg-white border-b border-gray-200">
      <div className="p-4">
        <h1 className="text-xl font-semibold text-gray-800">Kod AI</h1>
      </div>
    </header>
  );
};

export default Header;