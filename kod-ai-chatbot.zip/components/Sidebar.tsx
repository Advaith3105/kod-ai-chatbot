import React from 'react';
import PlusIcon from './icons/PlusIcon';
import MessageIcon from './icons/MessageIcon';
import KodAiLogo from './icons/KodAiLogo';

const Sidebar: React.FC = () => {
  return (
    <aside className="w-64 bg-gray-800 text-white flex flex-col">
      <div className="p-4 border-b border-gray-700 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <KodAiLogo className="w-7 h-7 text-blue-400" />
          <span className="text-lg font-semibold">Kod AI</span>
        </div>
        <button className="p-2 text-gray-400 hover:bg-gray-700 hover:text-white rounded-lg transition-colors" title="New Chat">
          <PlusIcon className="w-5 h-5" />
        </button>
      </div>
      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        <a href="#" className="flex items-center px-3 py-2 text-gray-300 hover:bg-gray-700 rounded-md">
          <MessageIcon className="w-5 h-5 mr-3" />
          <span className="truncate">Conversation about React</span>
        </a>
        <a href="#" className="flex items-center px-3 py-2 text-gray-300 hover:bg-gray-700 rounded-md">
          <MessageIcon className="w-5 h-5 mr-3" />
          <span className="truncate">How to make sourdough</span>
        </a>
      </nav>
      <div className="p-4 border-t border-gray-700">
        {/* User profile or settings can go here */}
      </div>
    </aside>
  );
};

export default Sidebar;
