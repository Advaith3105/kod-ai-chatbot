import React, { useRef, useEffect } from 'react';
import { ChatMessage as ChatMessageType } from '../types';
import ChatMessage from './ChatMessage';
import LoadingSpinner from './LoadingSpinner';
import BotIcon from './icons/BotIcon';

interface ChatHistoryProps {
  messages: ChatMessageType[];
  isLoading: boolean;
}

const ChatHistory: React.FC<ChatHistoryProps> = ({ messages, isLoading }) => {
  const endOfMessagesRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    endOfMessagesRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  return (
    <div className="space-y-6">
      {messages.map((msg, index) => (
        <ChatMessage key={index} message={msg} />
      ))}
      {/* FIX: Add check for messages.length > 0 to prevent error on empty messages array */}
      {isLoading && messages.length > 0 && messages[messages.length - 1].role === 'user' && (
         <div className="flex items-start gap-4 justify-start">
            <div className="w-10 h-10 flex-shrink-0 bg-blue-600 rounded-full p-2">
              <BotIcon className="w-full h-full text-white" />
            </div>
            <div className="max-w-xl p-4 rounded-t-2xl rounded-br-2xl shadow-lg bg-white border border-gray-200">
              <LoadingSpinner />
            </div>
         </div>
      )}
      <div ref={endOfMessagesRef} />
    </div>
  );
};

export default ChatHistory;
