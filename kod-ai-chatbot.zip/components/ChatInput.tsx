import React, { useState, KeyboardEvent, useRef, useEffect, ChangeEvent } from 'react';
import PaperclipIcon from './icons/PaperclipIcon';

interface ChatInputProps {
  onSendMessage: (input: string, file: File | null) => void;
  isLoading: boolean;
}

const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage, isLoading }) => {
  const [input, setInput] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        alert('Please select an image file.');
        return;
      }
      setSelectedFile(file);
      setPreviewUrl(URL.createObjectURL(file));
    }
  };

  const removeFile = () => {
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
    }
    setSelectedFile(null);
    setPreviewUrl(null);
    if(fileInputRef.current) {
        fileInputRef.current.value = "";
    }
  };
  
  const handleSubmit = () => {
    if ((input.trim() || selectedFile) && !isLoading) {
      onSendMessage(input, selectedFile);
      setInput('');
      removeFile();
    }
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      handleSubmit();
    }
  };
  
  useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto'; // Reset height
      const scrollHeight = textarea.scrollHeight;
      textarea.style.height = `${scrollHeight}px`;
    }
  }, [input]);

  return (
    <div className="w-full">
        {previewUrl && (
            <div className="p-2 bg-gray-100 rounded-t-lg relative w-fit mb-2">
                <img src={previewUrl} alt="Preview" className="h-20 w-20 object-cover rounded-md" />
                <button 
                    type="button"
                    onClick={removeFile}
                    className="absolute -top-2 -right-2 bg-gray-700 text-white rounded-full h-6 w-6 flex items-center justify-center text-xs hover:bg-red-500 transition-colors"
                    aria-label="Remove image"
                >
                    &#x2715;
                </button>
            </div>
        )}
      <div className="relative flex items-end p-2 bg-gray-100 rounded-lg">
        <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={isLoading}
            className="p-2 text-gray-500 hover:text-blue-600 disabled:text-gray-300 transition-colors"
            aria-label="Attach file"
        >
            <PaperclipIcon className="h-6 w-6" />
        </button>
        <input 
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            className="hidden"
            accept="image/*"
        />
        <textarea
          ref={textareaRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Type your message..."
          disabled={isLoading}
          rows={1}
          className="w-full max-h-40 resize-none bg-transparent border-none p-2 text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-0"
          aria-label="Chat input"
        />
        <button
          type="button"
          onClick={handleSubmit}
          disabled={isLoading || (!input.trim() && !selectedFile)}
          className="bg-blue-600 text-white rounded-full p-2.5 ml-2 disabled:bg-gray-400 disabled:cursor-not-allowed hover:bg-blue-700 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 self-center flex-shrink-0"
          aria-label="Send message"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
          </svg>
        </button>
      </div>
    </div>
  );
};

export default ChatInput;
