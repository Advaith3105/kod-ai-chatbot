import React from 'react';
import { ChatMessage as ChatMessageType } from '../types';
import BotIcon from './icons/BotIcon';
import UserIcon from './icons/UserIcon';
import Markdown from 'react-markdown';

interface ChatMessageProps {
  message: ChatMessageType;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isUser = message.role === 'user';
  
  const icon = isUser ? (
    <div className="w-10 h-10 flex-shrink-0 bg-gray-600 rounded-full p-2">
      <UserIcon className="w-full h-full text-white" />
    </div>
  ) : (
    <div className="w-10 h-10 flex-shrink-0 bg-blue-600 rounded-full p-2">
      <BotIcon className="w-full h-full text-white" />
    </div>
  );
  
  const messageBubbleClasses = isUser
    ? "bg-blue-600 text-white rounded-t-2xl rounded-bl-2xl"
    : "bg-white border border-gray-200 text-gray-800 rounded-t-2xl rounded-br-2xl";

  const containerClasses = `flex items-start gap-4 ${isUser ? 'justify-end' : 'justify-start'}`;

  return (
    <div className={containerClasses}>
      {!isUser && icon}
      <div className={`max-w-xl p-4 shadow-lg ${messageBubbleClasses}`}>
        {message.parts.map((part, index) => (
          <div key={index}>
            {part.imageData && (
              <img 
                src={part.imageData.url} 
                alt="User upload" 
                className="max-w-xs rounded-lg mb-2"
              />
            )}
            {part.text && (
               <div className="prose prose-sm max-w-none text-inherit">
                 <Markdown>{part.text}</Markdown>
               </div>
            )}
          </div>
        ))}
      </div>
      {isUser && icon}
    </div>
  );
};

export default ChatMessage;
